# Community Examples

This folder used to contain community maintained example configurations for
Kubernetes and Traefik. They have now been migrated to the [jitsi-contrib](https://github.com/jitsi-contrib)
organization.
